package sistema_de_tickes;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import java.io.File;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

/**

 * @author denil
 */

public class SistemaController {

    @FXML private TextField fldNombre;
    @FXML private TextField fldVencimiento;
    @FXML private ComboBox<String> boxIdioma;
    @FXML private ComboBox<String> boxHorario;
    @FXML private ComboBox<String> boxPrioridad;
    @FXML private DatePicker datePickerTiempoTicket;
    @FXML private ImageView img;
    @FXML private Button btnImagen;
    @FXML private Button btnCancelar;
    @FXML private Button btnRegresar;
    @FXML private Button btnRegistrar;
    @FXML private Pane paneRegistrar;
    @FXML private MenuButton BotonMenu;
    @FXML private MenuItem Usuarios;
    @FXML private MenuItem itemRoles;
    @FXML private MenuItem itemTicket;
    @FXML private MenuItem itemDepartamento;
    @FXML private MenuItem itemDetallesTicket;
    @FXML private MenuItem itemFlujoDeTrabajo;
    @FXML private MenuItem itemHistorial;
    @FXML private MenuItem itemSalir;

    private ObservableList<String> prioridades = FXCollections.observableArrayList();

    public void initialize() {
        boxIdioma.setItems(FXCollections.observableArrayList("Español", "Inglés", "Francés"));
        boxHorario.setItems(FXCollections.observableArrayList("GMT-6", "GMT-5", "GMT-4", "GMT+1"));
        prioridades.addAll("Alta", "Media", "Baja");
        boxPrioridad.setItems(prioridades);
        img.setImage(null);
    }

    @FXML
    private void eventImagen(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar Imagen");
        fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg", "*.gif")
        );
        Stage stage = (Stage) btnImagen.getScene().getWindow();
        File file = fileChooser.showOpenDialog(stage);
        if (file != null) {
            Image imagen = new Image(file.toURI().toString());
            img.setImage(imagen);
        }
    }

    private void Registrar() {
        System.out.println("CONFIGURACIÓN REGISTRADA");
        System.out.println("Nombre Empresa: " + fldNombre.getText());
        System.out.println("Idioma: " + boxIdioma.getValue());
        System.out.println("Zona Horaria: " + boxHorario.getValue());
        System.out.println("Tiempo Ticket: " + datePickerTiempoTicket.getValue());
        System.out.println("Prioridad seleccionada: " + boxPrioridad.getValue());
        System.out.println("Vencimiento: " + fldVencimiento.getText());
        System.out.println("    ");
    }

    @FXML
    private void RegistrarDatos(MouseEvent event) {
        Registrar();
    }

    @FXML
    private void eventRegistrar(ActionEvent event) {
        Registrar();
    }

    @FXML
    private void eventCancelar(ActionEvent event) {
        fldNombre.clear();
        fldVencimiento.clear();
        boxIdioma.getSelectionModel().clearSelection();
        boxHorario.getSelectionModel().clearSelection();
        boxPrioridad.getSelectionModel().clearSelection();
        datePickerTiempoTicket.setValue(null);
        img.setImage(null);
    }

    @FXML
    private void eventRegresar(ActionEvent event) {
       cambiarPantalla("/Graficos/Login.fxml");
    }

    @FXML
    private void eventUsuarios(ActionEvent event) {
         cambiarPantalla("/Graficos/Usuarios.fxml");
    }

    @FXML
    private void eventRoles(ActionEvent event) {
        cambiarPantalla("/Graficos/RolesYPermisos.fxml");
    }

    @FXML
    private void eventTicket(ActionEvent event) {
        cambiarPantalla("/Graficos/Ticket.fxml");
    }

    @FXML
    private void eventDepartamento(ActionEvent event) {
         cambiarPantalla("/Graficos/Departamento.fxml");
    }

    @FXML
    private void eventDetalleTicket(ActionEvent event) {
         cambiarPantalla("/Graficos/Estado_de_ticket.fxml");
    }

    @FXML
    private void itemFlujoDeTrabajo(ActionEvent event) {
        cambiarPantalla("/Graficos/FlujodeTrabajo.fxml");
    }

    @FXML
    private void eventHistorial(ActionEvent event) {
        cambiarPantalla("/Graficos/Historial1.fxml");
    }

    @FXML
    private void eventSallir(ActionEvent event) {
       cambiarPantalla("/Graficos/Login.fxml");
    }

    private void showInfo(String titulo, String contenido) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
     private void cambiarPantalla(String rutaFXML) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) BotonMenu.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            System.err.println("No se pudo cargar la vista: " + rutaFXML);
            e.printStackTrace();
        }
     }}