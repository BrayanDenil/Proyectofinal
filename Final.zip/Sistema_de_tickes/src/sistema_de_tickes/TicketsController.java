package sistema_de_tickes;

import Modelos.Departamento;
import Modelos.Estado;
import Modelos.Tickets;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.text.Text;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class TicketsController implements Initializable {

    @FXML private Text txtTicket;
    @FXML private Text txtDescripcion;
    @FXML private Text txtTitulo;
    @FXML private Text txtEstado;
    @FXML private Text txtFechaCreacion;
    @FXML private Text txtCreador;
    @FXML private Text txtDepAsignado;

    @FXML private TextField fldTicket;
    @FXML private TextField fldDescripcion;
    @FXML private TextField fldTitulo;

    @FXML private DatePicker fldDate;

    @FXML private ComboBox<Estado> CbxEstado;
    @FXML private ComboBox<Departamento> CbxDepartamento;
    @FXML private ComboBox<String> boxCreador;

    @FXML private Button btnCrear;
    @FXML private Button btnRegresar;

    @FXML private MenuButton BotonMenu;
    @FXML private MenuItem itemTicket;
    @FXML private MenuItem itemDetallesTicket;
    @FXML private MenuItem itemSalir;

    private final List<Tickets> tickets = new ArrayList<>();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        CbxEstado.setItems(FXCollections.observableArrayList(Estado.values()));
        CbxDepartamento.setItems(FXCollections.observableArrayList(
            new Departamento("Soporte Tecnico"),
            new Departamento("Administración"),
            new Departamento("Finanzas")
        ));
        boxCreador.setItems(FXCollections.observableArrayList("Admin", "Usuario1", "Usuario2"));
        fldDate.setValue(LocalDate.now());
    }

    @FXML
    private void eventCrear(ActionEvent event) {
        String titulo = fldTitulo.getText().trim();
        String descripcion = fldDescripcion.getText().trim();
        Departamento departamento = CbxDepartamento.getValue();
        Estado estado = CbxEstado.getValue();
        String creador = boxCreador.getValue();
        LocalDate fecha = fldDate.getValue();

        if (titulo.isEmpty() || descripcion.isEmpty() || departamento == null || estado == null || creador == null || fecha == null) {
            mostrarAlerta("Error", "Por favor, completa todos los campos.");
            return;
        }

        Tickets nuevo = new Tickets(titulo, descripcion, departamento, "Media", creador);
        nuevo.setEstado(estado);
        tickets.add(nuevo);

        mostrarDetallesTicket(nuevo);
        mostrarAlerta("Éxito", "Ticket creado correctamente.");
        limpiarFormulario();
    }

    @FXML
    private void eventRegresar(ActionEvent event) {
        mostrarAlerta("Regresar", "Volviendo a la pantalla anterior...");
    }

    private void mostrarDetallesTicket(Tickets ticket) {
        txtTicket.setText("ID: " + ticket.getId());
        txtTitulo.setText(ticket.getTitulo());
        txtDescripcion.setText(ticket.getDescripcion());
        txtEstado.setText(ticket.getEstado().toString());
        txtFechaCreacion.setText(ticket.getFechaCreacion().toString());
        txtCreador.setText(ticket.getCreadoPor());
        //txtDepAsignado.setText(ticket.getDepartamento().getNombre());
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void limpiarFormulario() {
        fldTitulo.clear();
        fldDescripcion.clear();
        CbxEstado.getSelectionModel().clearSelection();
        CbxDepartamento.getSelectionModel().clearSelection();
        boxCreador.getSelectionModel().clearSelection();
        fldDate.setValue(LocalDate.now());
    }

    @FXML
    private void eventTicket(ActionEvent event) {
        mostrarAlerta("Ticket", "Pantalla de tickets.");
    }

    @FXML
    private void eventDetalleTicket(ActionEvent event) {
        mostrarAlerta("Detalles", "Ver detalles de ticket.");
    }

    @FXML
    private void eventSalir(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    private void eventCambiarPantallla(ActionEvent event) {
        mostrarAlerta("Cambio de pantalla", "Función no implementada.");
    }
}