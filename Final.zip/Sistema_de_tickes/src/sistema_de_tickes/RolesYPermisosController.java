package sistema_de_tickes;

import Modelos.RolesYPermiso;
import Modelos.Permiso;
import Modelos.Usuario;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**

 * @author denil
 */


public class RolesYPermisosController implements Initializable {
    private List<RolesYPermiso> roles = new ArrayList<>();
    private ObservableList<Usuario> listaUsuarios = FXCollections.observableArrayList();

    @FXML
    private ListView<String> listaRolesYPermiso;

    @FXML
    private Text txtPermisos;

    @FXML
    private Text txtNombre;

    @FXML
    private Text txtDescripcion;

    private Text txfDescripcion;

    @FXML
    private TextField fldPermisos;

    @FXML
    private TextField fldDescripcion;

    @FXML
    private ComboBox<Usuario> cmbox;

    @FXML
    private Button btnCrear;

    @FXML
    private Button btnEliminar;

    @FXML
    private Button bltRegresar;

    @FXML
    private Button btnHistorial;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarUsuarios();
        cargarRoles();
        actualizarListaRoles();

        listaRolesYPermiso.setOnMouseClicked(event -> {
            String seleccionado = listaRolesYPermiso.getSelectionModel().getSelectedItem();
            RolesYPermiso rol = roles.stream()
                .filter(r -> r.getNombre().equals(seleccionado))
                .findFirst()
                .orElse(null);
            if (rol != null) {
                txfDescripcion.setText("Descripción: " + rol.getDescripcion());
                txtPermisos.setText("Permisos: " + rol.getPermisos().stream()
                    .map(Permiso::getNombre)
                    .collect(Collectors.joining(", ")));
            }
        });
    }

    private void cargarUsuarios() {
        listaUsuarios.add(new Usuario("001", "admin", "Admin", "admin@correo.com", "admin123", "1234567890", "Administrador", "TI", "2023-01-01", "TI"));
        listaUsuarios.add(new Usuario("002", "tecnico", "Tecnico", "tecnico@correo.com", "tecnico123", "0987654321", "Técnico", "Soporte", "2022-01-01", "Soporte"));
        listaUsuarios.add(new Usuario("003", "cliente", "Cliente", "cliente@correo.com", "cliente123", "1122334455", "Cliente", "Ventas", "2021-01-01", "Ventas"));
        cmbox.setItems(listaUsuarios);
    }

    private void cargarRoles() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("roles.dat"))) {
            roles = (List<RolesYPermiso>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("No se pudieron cargar los roles.");
        }
    }

    private void guardarRoles() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("roles.dat"))) {
            oos.writeObject(roles);
        } catch (IOException e) {
            System.out.println("No se pudieron guardar los roles.");
        }
    }

    @FXML
    private void eventCreaRol(ActionEvent event) {
        Usuario usuarioSeleccionado = cmbox.getValue();
        String descripcion = fldDescripcion.getText().trim();
        String nombreRol = fldPermisos.getText().trim();

        if (usuarioSeleccionado == null) {
            mostrarAlerta("Nombre inválido", "Debe seleccionar un usuario para asociar un rol.");
            return;
        }

        if (nombreRol.length() < 3 || nombreRol.length() > 50) {
            mostrarAlerta("Nombre inválido", "El nombre del rol debe tener entre 3 y 50 caracteres.");
            return;
        }

        boolean existe = roles.stream().anyMatch(r -> r.getNombre().equalsIgnoreCase(nombreRol));
        if (existe) {
            mostrarAlerta("Duplicado", "Ya existe un rol con ese nombre.");
            return;
        }

        RolesYPermiso nuevoRol = new RolesYPermiso(nombreRol, descripcion);
        nuevoRol.agregarPermiso(new Permiso("Ver tickets", "Permite ver los tickets creados."));
        nuevoRol.agregarPermiso(new Permiso("Crear tickets", "Permite crear nuevos tickets."));

        roles.add(nuevoRol);
        registrarCambio(usuarioSeleccionado.getNombre(), "Creó el rol con permisos básicos.");
        actualizarListaRoles();
        guardarRoles();
        limpiarCampos();
    }

    @FXML
    private void eventEliminar(ActionEvent event) {
        String seleccionado = listaRolesYPermiso.getSelectionModel().getSelectedItem();
        if (seleccionado != null) {
            RolesYPermiso rolAEliminar = roles.stream()
                .filter(rol -> rol.getNombre().equals(seleccionado))
                .findFirst()
                .orElse(null);

            if (rolAEliminar != null) {
                roles.remove(rolAEliminar);
                registrarCambio(rolAEliminar.getNombre(), "Eliminó el rol.");
                actualizarListaRoles();
                guardarRoles();
            }
        } else {
            mostrarAlerta("Selección requerida", "Debe seleccionar un rol de la lista para eliminar.");
        }
    }

    @FXML
    private void eventRegresar(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Sistema.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) bltRegresar.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void eventHistorial(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Historial1.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnHistorial.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void actualizarListaRoles() {
        listaRolesYPermiso.getItems().clear();
        for (RolesYPermiso rol : roles) {
            listaRolesYPermiso.getItems().add(rol.getNombre());
        }
    }

    private void limpiarCampos() {
        cmbox.getSelectionModel().clearSelection();
        fldDescripcion.clear();
        fldPermisos.clear();
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    public static void registrarCambio(String usuario, String accion) {
        try (FileWriter fw = new FileWriter("historial_cambios.log", true);
             PrintWriter pw = new PrintWriter(fw)) {
            pw.println(LocalDateTime.now() + " - Usuario: " + usuario + " - Acción: " + accion);
        } catch (IOException e) {
            System.out.println("No se pudo registrar el historial.");
        }
    }
}