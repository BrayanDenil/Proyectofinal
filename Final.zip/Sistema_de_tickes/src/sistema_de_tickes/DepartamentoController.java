package sistema_de_tickes;

import Modelos.Departamento;
import Modelos.Tecnico;
import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class DepartamentoController implements Initializable {

    @FXML private Button btlRegresar;
    @FXML private Label txtDepartamento;
    @FXML private Label txtTecnico;
    @FXML private Label txtCracion;
    @FXML private Label txtCierre;
    @FXML private Button btnAgregar;
    @FXML private Button btnEliminar;
    @FXML private DatePicker dateCreacion;
    @FXML private DatePicker dateCierre;
    @FXML private Label txtDescripcion;
    @FXML private TextField fldDescripcion;

    @FXML private ComboBox<Departamento> cbxDepartamento;
    @FXML private ComboBox<Tecnico> cbxTecnico;

    private List<Departamento> departamentos = new ArrayList<>();
    private List<Tecnico> tecnicosDisponibles = new ArrayList<>();

    private final String ARCHIVO_DEPARTAMENTOS = "departamentos.txt";
    private final String ARCHIVO_TECNICOS = "tecnicos.txt";

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarDepartamentos();
        cargarTecnicos();

      
        cbxDepartamento.setCellFactory(lv -> new ListCell<Departamento>() {
            @Override
            protected void updateItem(Departamento item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getNombre());
            }
        });
        cbxDepartamento.setButtonCell(new ListCell<Departamento>() {
            @Override
            protected void updateItem(Departamento item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getNombre());
            }
        });

     
        cbxTecnico.setCellFactory(lv -> new ListCell<Tecnico>() {
            @Override
            protected void updateItem(Tecnico item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getNombre());
            }
        });
        cbxTecnico.setButtonCell(new ListCell<Tecnico>() {
            @Override
            protected void updateItem(Tecnico item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getNombre());
            }
        });
    }

    private void cargarDepartamentos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_DEPARTAMENTOS))) {
            departamentos = (List<Departamento>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            departamentos = new ArrayList<>();
        }
        cbxDepartamento.setItems(FXCollections.observableArrayList(departamentos));
    }

    private void guardarDepartamentos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_DEPARTAMENTOS))) {
            oos.writeObject(departamentos);
        } catch (IOException e) {
            mostrarAlerta("Error", "Hubo un error al guardar los departamentos.");
        }
    }

    private void cargarTecnicos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_TECNICOS))) {
            tecnicosDisponibles = (List<Tecnico>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            tecnicosDisponibles = new ArrayList<>();
        }
        cbxTecnico.setItems(FXCollections.observableArrayList(tecnicosDisponibles));
    }

    @FXML
    private void Agregar(ActionEvent event) {
        Departamento depSeleccionado = cbxDepartamento.getValue();
        String descripcion = fldDescripcion.getText().trim();
        Tecnico tecnicoSeleccionado = cbxTecnico.getValue();
        java.time.LocalDate fechaCreacion = dateCreacion.getValue();
        java.time.LocalDate fechaCierre = dateCierre.getValue();

        if (depSeleccionado == null) {
            mostrarAlerta("Error", "Debe seleccionar un departamento.");
            return;
        }
        if (descripcion.isEmpty()) {
            mostrarAlerta("Error", "La descripción no puede estar vacía.");
            return;
        }
        if (tecnicoSeleccionado == null) {
            mostrarAlerta("Error", "Debe seleccionar un técnico asignado.");
            return;
        }
        if (!esFechaValida(fechaCreacion, fechaCierre)) {
            mostrarAlerta("Error", "La fecha de cierre no puede ser anterior a la fecha de creación.");
            return;
        }
        if (existeDepartamento(depSeleccionado.getNombre())) {
            mostrarAlerta("Error", "Ya existe un departamento con ese nombre.");
            return;
        }

        Departamento nuevo = new Departamento(depSeleccionado.getNombre(), descripcion);
        List<Tecnico> tecnicosAsignados = new ArrayList<>();
        tecnicosAsignados.add(tecnicoSeleccionado);
        nuevo.setTecnicoAsignados(tecnicosAsignados);
        nuevo.setFechaCreacion(fechaCreacion);
        nuevo.setFechaCierre(fechaCierre);

        departamentos.add(nuevo);
        guardarDepartamentos();

        mostrarAlerta("Éxito", "Departamento registrado exitosamente.");
        limpiarCampos();

        cbxDepartamento.setItems(FXCollections.observableArrayList(departamentos));
    }

    @FXML
    private void Eliminar(ActionEvent event) {
        Departamento depSeleccionado = cbxDepartamento.getValue();

        if (depSeleccionado == null) {
            mostrarAlerta("Error", "Debe seleccionar un departamento para eliminar.");
            return;
        }

        Optional<Departamento> dep = departamentos.stream()
                .filter(d -> d.getNombre().equalsIgnoreCase(depSeleccionado.getNombre()))
                .findFirst();

        if (dep.isPresent()) {
            Departamento departamento = dep.get();

            if (departamento.getColaAtencion() != null && !departamento.getColaAtencion().isEmpty()) {
                mostrarAlerta("Advertencia", "No se puede eliminar un departamento con tickets activos.");
            } else {
                Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);
                confirmacion.setTitle("Confirmar eliminación");
                confirmacion.setHeaderText("¿Estás seguro de que deseas eliminar este departamento?");
                Optional<ButtonType> result = confirmacion.showAndWait();

                if (result.isPresent() && result.get() == ButtonType.OK) {
                    departamentos.remove(departamento);
                    guardarDepartamentos();
                    mostrarAlerta("Éxito", "Departamento eliminado.");
                    cbxDepartamento.setItems(FXCollections.observableArrayList(departamentos));
                    limpiarCampos();
                }
            }
        } else {
            mostrarAlerta("Error", "Departamento no encontrado.");
        }
    }

    private boolean existeDepartamento(String nombre) {
        return departamentos.stream().anyMatch(d -> d.getNombre().equalsIgnoreCase(nombre));
    }

    private boolean esFechaValida(java.time.LocalDate fechaCreacion, java.time.LocalDate fechaCierre) {
        return fechaCreacion != null && (fechaCierre == null || !fechaCierre.isBefore(fechaCreacion));
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void limpiarCampos() {
        cbxDepartamento.setValue(null);
        fldDescripcion.clear();
        cbxTecnico.setValue(null);
        dateCreacion.setValue(null);
        dateCierre.setValue(null);
    }

    @FXML
    private void eventRegresar(ActionEvent event) {
        try {
            guardarDepartamentos();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Sistema.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) btlRegresar.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}