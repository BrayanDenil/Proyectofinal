 package sistema_de_tickes;

import Modelos.Tickets;
import sistema_de_tickes.Persistencia;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.List;
/**
 * FXML Controller class
 *
 * @author denil
 */
public class NotaController {

    @FXML private TextArea txtNota;
    @FXML private TextField txtArchivo;

    private File archivoAdjunto;
    private Tickets ticket;
    private String autor; 
    private List<Tickets> listaTickets;

    public void inicializar(Tickets ticket, String autor, List<Tickets> listaCompleta) {
        this.ticket = ticket;
        this.autor = autor;
        this.listaTickets = listaCompleta;
    }

    @FXML
    private void seleccionarArchivo() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar archivo adjunto");
        
        
        FileChooser.ExtensionFilter filtroPDF = new FileChooser.ExtensionFilter("Archivos PDF (*.pdf)", "*.pdf");
        FileChooser.ExtensionFilter filtroImagen = new FileChooser.ExtensionFilter("Imágenes (*.png, *.jpg)", "*.png", "*.jpg");
        fileChooser.getExtensionFilters().addAll(filtroPDF, filtroImagen);

        archivoAdjunto = fileChooser.showOpenDialog(null);
        if (archivoAdjunto != null) {
            txtArchivo.setText(archivoAdjunto.getName());
        }
    }

    @FXML
    private void guardarNota() {
        String contenido = txtNota.getText().trim();

        if (contenido.isEmpty()) {
            mostrarAlerta("La nota no puede estar vacía.");
            return;
        }

        String mensaje = contenido;

        if (archivoAdjunto != null) {
            try {
            
                File destino = new File("adjuntos/" + archivoAdjunto.getName());
                destino.getParentFile().mkdirs(); 
                Files.copy(archivoAdjunto.toPath(), destino.toPath(), StandardCopyOption.REPLACE_EXISTING);

                mensaje += " [Adjunto: " + destino.getPath() + "]";
            } catch (IOException e) {
                mostrarAlerta("Error al copiar el archivo adjunto.");
                return;
            }
        }

        ticket.agregarNota(autor, mensaje);
        Persistencia.guardarListaTickets(listaTickets);
        cerrarVentana();
    }

    @FXML
    private void cancelar() {
        cerrarVentana();
    }

    private void mostrarAlerta(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Advertencia");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void cerrarVentana() {
        Stage stage = (Stage) txtNota.getScene().getWindow();
        stage.close();
    }
}
