package sistema_de_tickes;

import Modelos.Departamento;
import Modelos.Tickets;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Persistencia {

    public static <T> void guardarDatos(String ruta, ObservableList<T> lista) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            List<T> listaNormal = new ArrayList<>(lista); 
            oos.writeObject(listaNormal);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error al guardar los datos en " + ruta);
        }
    }

    
    @SuppressWarnings("unchecked")
    public static <T> ObservableList<T> cargarDatos(String ruta) {
        File archivo = new File(ruta);
        if (!archivo.exists()) {
            return FXCollections.observableArrayList(); 
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            List<T> listaNormal = (List<T>) ois.readObject();
            return FXCollections.observableArrayList(listaNormal);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            System.err.println("Error al cargar los datos desde " + ruta);
            return FXCollections.observableArrayList(); 
        }
    }

   
    public static List<Tickets> cargarListaTickets() {
        String ruta = "tickets.dat"; 
        return cargarDatos(ruta);
    }


    public static List<Departamento> cargarListaDepartamentos() {
        String ruta = "departamentos.dat";  
        return cargarDatos(ruta);
    }

    
    public static void guardarListaTickets(List<Tickets> todosLosTickets) {
        String ruta = "tickets.dat";
        ObservableList<Tickets> observableTickets = FXCollections.observableArrayList(todosLosTickets);
        guardarDatos(ruta, observableTickets);
    }

 
    public static void guardarListaDepartamentos(List<Departamento> todosLosDepartamentos) {
        String ruta = "departamentos.dat";  
        ObservableList<Departamento> observableDepartamentos = FXCollections.observableArrayList(todosLosDepartamentos);
        guardarDatos(ruta, observableDepartamentos);
    }

    static String obtenerDepartamentoDeTecnico(String nombre) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
