package Modelos;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Departamento implements Serializable {

    private static final long serialVersionUID = 1L;

    private String nombre;
    private String descripcion;
    private List<Tecnico> tecnicoAsignados;
    private Queue<Tickets> colaAtencion;
    private String soporteTecnico;

    private LocalDate fechaCreacion;
    private LocalDate fechaCierre;

    // Constructor principal
    public Departamento(String nombre) {
        this.nombre = nombre;
        this.descripcion = "";
        this.soporteTecnico = "";
        this.tecnicoAsignados = new ArrayList<>();
        this.colaAtencion = new LinkedList<>();
        this.fechaCreacion = LocalDate.now();
    }

    // Constructor extendido si se desea más información
    public Departamento(String nombre, String descripcion, String soporteTecnico) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.soporteTecnico = soporteTecnico;
        this.tecnicoAsignados = new ArrayList<>();
        this.colaAtencion = new LinkedList<>();
        this.fechaCreacion = LocalDate.now();
    }

    Departamento(String soporte_Técnico, String departamento_de_soporte_técnico) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Métodos Getter y Setter
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public List<Tecnico> getTecnicoAsignados() {
        return tecnicoAsignados;
    }

    public void setTecnicoAsignados(List<Tecnico> tecnicoAsignados) {
        this.tecnicoAsignados = tecnicoAsignados;
    }

    public Queue<Tickets> getColaAtencion() {
        return colaAtencion;
    }

    public void setColaAtencion(Queue<Tickets> colaAtencion) {
        this.colaAtencion = colaAtencion;
    }

    public String getSoporteTecnico() {
        return soporteTecnico;
    }

    public void setSoporteTecnico(String soporteTecnico) {
        this.soporteTecnico = soporteTecnico;
    }

    public LocalDate getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDate fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public LocalDate getFechaCierre() {
        return fechaCierre;
    }

    public void setFechaCierre(LocalDate fechaCierre) {
        this.fechaCierre = fechaCierre;
    }

    public void agregarTicket(Tickets nuevoTicket) {
        colaAtencion.add(nuevoTicket);
    }

    @Override
    public String toString() {
        return nombre;
    }
}