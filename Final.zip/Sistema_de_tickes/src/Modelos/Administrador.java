package Modelos;

/**

 * @author denil
 */
public class Administrador extends Persona {

    public Administrador(String usuario, String nombre, String apellido, String correo,
                         String contraseña, String telefono, String rol, String area, String ingreso) {
        super(usuario, nombre, apellido, correo, contraseña, telefono, rol, area, ingreso);
    }
}

