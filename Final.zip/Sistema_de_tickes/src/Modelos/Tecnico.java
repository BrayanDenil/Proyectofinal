package Modelos;

/**
 * Clase Tecnico que extiende de Persona.
 * Autor: denil
 */
public class Tecnico extends Persona {

    public Tecnico(String codigoUsuario, String nombre, String apellido, String correo,
                   String contraseña, String telefono, String rol, String area, String ingresoStr) {
        super(codigoUsuario, nombre, apellido, correo, contraseña, telefono, rol, area, ingresoStr);
    }

    @Override
    public String toString() {
        // Mostrar nombre completo del técnico
        return getNombre() + " " + getApellido();
    }
}