package sistema_de_tickes;

import Modelos.Tickets;
import Modelos.Departamento;
import Modelos.Estado;
import sistema_de_tickes.Persistencia;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

import java.net.URL;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * FXML Controller class
 *
 * @author denil
 */

public class Solicitudes_pendienesController implements Initializable {

    private List<Tickets> todosLosTickets;
    private ObservableList<Tickets> ticketsVisibles = FXCollections.observableArrayList();

    private String rolUsuario = "usuario"; 
    private String nombreUsuario = "";    

    @FXML private Text txtBuscar;
    @FXML private TextField fldBuscar;
    @FXML private TableColumn<?, ?> Tabla;
    @FXML private Button btnDatalles;
    @FXML private Button btnAgregarNota;
    @FXML private Button btnCambiarEstado;
    @FXML private Button btnReasignar;
    @FXML private TextArea txtNotas;

    @FXML private Pane panelUsuario;
    @FXML private Pane panelTecnico;
    @FXML private Pane panelAdmin;

    @FXML private ComboBox<String> cbxFiltroEstado;
    @FXML private ComboBox<String> cbxFiltroPrioridad;
    @FXML private ComboBox<Departamento> cbxFiltroDepartamento;
    @FXML private DatePicker dpFiltroFechaCreacion;
    @FXML private TextField txtBuscarTicket;
    @FXML private ListView<Tickets> lstTickets;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarFiltros();
        cargarDatos();
        configurarPorRol();
        aplicarFiltros();
    }

    private void cargarFiltros() {
        cbxFiltroEstado.setItems(FXCollections.observableArrayList("Pendiente", "En proceso", "Escalado", "Cerrado"));
        cbxFiltroPrioridad.setItems(FXCollections.observableArrayList("Alta", "Media", "Baja"));
        cbxFiltroDepartamento.setItems(FXCollections.observableList(cargarDepartamentos()));
    }

    private void cargarDatos() {
        todosLosTickets = cargarTickets();
        lstTickets.setItems(ticketsVisibles);
    }

    private List<Tickets> cargarTickets() {
        return Persistencia.cargarListaTickets(); 
    }

    private List<Departamento> cargarDepartamentos() {
        return Persistencia.cargarListaDepartamentos(); 
    }

    private void configurarPorRol() {
        panelUsuario.setVisible(rolUsuario.equals("usuario"));
        panelTecnico.setVisible(rolUsuario.equals("tecnico"));
        panelAdmin.setVisible(rolUsuario.equals("administrador"));
    }

   private void aplicarFiltros() {
    String filtroEstado = cbxFiltroEstado.getValue();
    String filtroPrioridad = cbxFiltroPrioridad.getValue();
    Departamento filtroDepto = cbxFiltroDepartamento.getValue();
    LocalDate filtroFecha = dpFiltroFechaCreacion.getValue();
    String textoBusqueda = txtBuscarTicket.getText().trim().toLowerCase();

    List<Tickets> filtrados = todosLosTickets.stream()
        
        .filter(t -> filtroEstado == null || (t.getEstado() != null && t.getEstado().toString().equalsIgnoreCase(filtroEstado)))
        .filter(t -> filtroPrioridad == null || (t.getPrioridad() != null && t.getPrioridad().equalsIgnoreCase(filtroPrioridad)))
        .filter(t -> filtroDepto == null || (t.getDepartamentoAsignado() != null && t.getDepartamentoAsignado().equalsIgnoreCase(filtroDepto.getNombre())))
        .filter(t -> filtroFecha == null || (t.getFechaCreacion() != null && t.getFechaCreacion().equals(filtroFecha)))
       /* .filter(t -> textoBusqueda.isEmpty() || (t.getId() != null && t.getId().toLowerCase().contains(textoBusqueda)))
        */.collect(Collectors.toList());

    ticketsVisibles.setAll(filtrados);

    if (filtrados.isEmpty()) {
        mostrarMensaje("No se encontraron tickets que coincidan con los filtros.");
    }
    }
    private String obtenerDepartamentoTecnico(String nombre) {
        return Persistencia.obtenerDepartamentoDeTecnico(nombre);
    }

    @FXML
    private void verDetalles() {
        Tickets t = lstTickets.getSelectionModel().getSelectedItem();
        if (t != null) {
            txtNotas.setText(t.getDescripcion() + "\n\nHistorial:\n" + t.getHistorial());
        }
    }

    @FXML
    private void agregarNota() {
        Tickets t = lstTickets.getSelectionModel().getSelectedItem();
        String nota = txtNotas.getText().trim();
        if (t != null && !nota.isEmpty()) {
            t.agregarNota(nombreUsuario, nota);
            Persistencia.guardarListaTickets(todosLosTickets);
            aplicarFiltros();
        }
    }

    @FXML
    private void cambiarEstado() {
        Tickets t = lstTickets.getSelectionModel().getSelectedItem();
        if (t != null) {
            Estado nuevo = Estado.EN_PROCESO; // puedes adaptar esto a una selección
            t.cambiarEstado(nuevo, nombreUsuario);
            Persistencia.guardarListaTickets(todosLosTickets);
            aplicarFiltros();
        }
    }

    @FXML
 /*   private void reasignarTicket() {
        if (!rolUsuario.equals("administrador")) return;

        Tickets t = lstTickets.getSelectionModel().getSelectedItem();
        Departamento nuevoDepto = cbxFiltroDepartamento.getValue();
        if (t != null && nuevoDepto != null) {
            t.setDepartamentoAsignado(nuevoDepto.getNombre());
            t.agregarNota("Sistema", "Ticket reasignado al departamento: " + nuevoDepto.getNombre());
            Persistencia.guardarListaTickets(todosLosTickets);
            aplicarFiltros();*/
        
    

    private void mostrarMensaje(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    public void setRolYUsuario(String rol, String nombre) {
        this.rolUsuario = rol;
        this.nombreUsuario = nombre;
    }
}
