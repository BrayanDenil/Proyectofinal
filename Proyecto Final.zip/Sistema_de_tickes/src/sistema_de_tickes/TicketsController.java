package sistema_de_tickes;

import Modelos.Estado;
import Modelos.Tickets;
import Modelos.Departamento;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.text.Text;

import java.io.PrintWriter;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class TicketsController implements Initializable {

    @FXML private Text txtTicket;
    @FXML private Text txtDescripcion;
    @FXML private Text txtTitulo;
    @FXML private Text txtEstado;
    @FXML private Text txtFechaCreacion;
    @FXML private Text txtCreador;
    @FXML private Text txtDepAsignado;

    @FXML private TextField fldTicket;
    @FXML private TextField fldDescripcion;
    @FXML private TextField fldTitulo;

    @FXML private DatePicker fldDate;

    @FXML private ComboBox<Estado> CbxEstado;
    @FXML private ComboBox<Departamento> CbxDepartamento;
    @FXML private ComboBox<String> boxCreador;

    @FXML private Button btnCrear;
    @FXML private Button btnRegresar;

    @FXML private MenuButton BotonMenu;
    @FXML private MenuItem itemTicket;
    @FXML private MenuItem itemDetallesTicket;
    @FXML private MenuItem itemSalir;

    private final List<Tickets> tickets = new ArrayList<>();
    private final List<String> historialAcciones = new ArrayList<>();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        CbxEstado.setItems(FXCollections.observableArrayList(Estado.values()));
        
       CbxDepartamento.setItems(FXCollections.observableArrayList(
         new Departamento("Soporte Tecnico"),
         new Departamento("Administración"),
         new Departamento("Finanzas")
        ));
        boxCreador.setItems(FXCollections.observableArrayList("Admin", "Usuario1", "Usuario2"));
        fldDate.setValue(LocalDate.now());

        registrarAccion("Aplicación iniciada");
    }

    @FXML
    private void eventCrear(ActionEvent event) {
        String titulo = fldTitulo.getText().trim();
        String descripcion = fldDescripcion.getText().trim();
        Departamento departamento = CbxDepartamento.getValue();
        Estado estado = CbxEstado.getValue();
        String creador = boxCreador.getValue();
        LocalDate fecha = fldDate.getValue();

        if (titulo.isEmpty() || descripcion.isEmpty() || departamento == null || estado == null || creador == null || fecha == null) {
            mostrarAlerta("Error", "Por favor, completa todos los campos.");
            registrarAccion("Error al crear ticket: campos incompletos");
            return;
        }

        Tickets nuevo = new Tickets(titulo, descripcion, departamento, "Media", creador);
        nuevo.setEstado(estado);
        tickets.add(nuevo);

        mostrarDetallesTicket(nuevo);
        mostrarAlerta("Éxito", "Ticket creado correctamente.");
        registrarAccion("Se creó un nuevo ticket: " + titulo);
        limpiarFormulario();
    }
    private void guardarTicketsEnArchivo() {
    try (PrintWriter writer = new PrintWriter("tickets.txt")) {
        for (Tickets ticket : tickets) {
            writer.println("ID: " + ticket.getId());
            writer.println("Título: " + ticket.getTitulo());
            writer.println("Descripción: " + ticket.getDescripcion());
            writer.println("Prioridad: " + ticket.getPrioridad());
            writer.println("Estado: " + ticket.getEstado());
            writer.println("Creador: " + ticket.getCreadoPor());
            writer.println("Fecha de creación: " + ticket.getFechaCreacion());
            writer.println("------------");
            
        }
    } catch (IOException e) {
        e.printStackTrace();
        mostrarAlerta("Error", "No se pudo guardar en tickets.txt");
    }
}

    private List<Departamento> cargarDepartamentosDesdeArchivo() {
    List<Departamento> departamentos = new ArrayList<>();
    try (java.util.Scanner scanner = new java.util.Scanner(new java.io.File("departamentos.txt"))) {
        while (scanner.hasNextLine()) {
            String nombre = scanner.nextLine().trim();
            if (!nombre.isEmpty()) {
                departamentos.add(new Departamento(nombre));
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
        mostrarAlerta("Error", "No se pudo cargar departamentos desde el archivo departamentos.txt.");
    }
    return departamentos;
}

    @FXML
    private void eventRegresar(ActionEvent event) {
         try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Sistema.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnRegresar.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void mostrarDetallesTicket(Tickets ticket) {
        txtTicket.setText("ID: " + ticket.getId());
        txtTitulo.setText(ticket.getTitulo());
        txtDescripcion.setText(ticket.getDescripcion());
        txtEstado.setText(ticket.getEstado().toString());
        txtFechaCreacion.setText(ticket.getFechaCreacion().toString());
        txtCreador.setText(ticket.getCreadoPor());
        // txtDepAsignado.setText(ticket.getDepartamento().getNombre()); // Descomenta si está en el FXML
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void limpiarFormulario() {
        fldTitulo.clear();
        fldDescripcion.clear();
        CbxEstado.getSelectionModel().clearSelection();
        CbxDepartamento.getSelectionModel().clearSelection();
        boxCreador.getSelectionModel().clearSelection();
        fldDate.setValue(LocalDate.now());
    }

    private void registrarAccion(String descripcion) {
        String timestamp = LocalDate.now() + " - " + descripcion;
        historialAcciones.add(timestamp);
        System.out.println("Historial: " + timestamp);
    }

    private void guardarHistorialEnArchivo() {
         try (PrintWriter writer = new PrintWriter("historial.txt")) {
        for (String accion : historialAcciones) {
            writer.println(accion);
        }
    } catch (IOException e) {
        e.printStackTrace();
        mostrarAlerta("Error", "No se pudo guardar el historial en historial.txt");
    }
    }

    @FXML
    private void eventTicket(ActionEvent event) {
        mostrarAlerta("Ticket", "Pantalla de tickets.");
        registrarAccion("Accedió a pantalla de tickets");
    }

    @FXML
    private void eventDetalleTicket(ActionEvent event) {
        mostrarAlerta("Detalles", "Ver detalles de ticket.");
        registrarAccion("Accedió a detalles de ticket");
    }

    @FXML
    private void eventSalir(ActionEvent event) {
        guardarHistorialEnArchivo();
        registrarAccion("Usuario salió del sistema");
        System.exit(0);
    }

    @FXML
    private void eventCambiarPantalla(ActionEvent event) {
        mostrarAlerta("Cambio de pantalla", "Función no implementada.");
        registrarAccion("Intentó cambiar de pantalla (no implementado)");
    }
}