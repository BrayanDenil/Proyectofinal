package sistema_de_tickes;

import Modelos.Departamento;
import Modelos.Tecnico;
import java.io.*;
import java.net.URL;
import java.time.LocalDate;
import java.util.*;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

/**
 * 
 *
 * @author denil
 */


public class DepartamentoController implements Initializable {

    @FXML private Button btlRegresar;
    @FXML private Label txtDepartamento;
    @FXML private Label txtTecnico;
    @FXML private Label txtCracion;
    @FXML private Label txtCierre;
    @FXML private Button btnAgregar;
    @FXML private Button btnEliminar;
    @FXML private DatePicker dateCreacion;
    @FXML private DatePicker dateCierre;
    @FXML private Label txtDescripcion;
    @FXML private TextField fldDescripcion;
    @FXML private TextField fldDepartamento;
    @FXML private ComboBox<Tecnico> cbxTecnico;

    private List<Departamento> departamentos = new ArrayList<>();
    private List<Tecnico> tecnicosDisponibles = new ArrayList<>();

    private final String ARCHIVO_DEPARTAMENTOS = "departamentos.txt";
    private final String ARCHIVO_USUARIOS = "usuarios.txt";

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarDepartamentos();
        cargarTecnicosDesdeArchivo();

        
        cbxTecnico.setCellFactory(lv -> new ListCell<Tecnico>() {
            @Override
            protected void updateItem(Tecnico item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.toString());
            }
        });
        cbxTecnico.setButtonCell(new ListCell<Tecnico>() {
            @Override
            protected void updateItem(Tecnico item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.toString());
            }
        });
    }

    private void cargarDepartamentos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_DEPARTAMENTOS))) {
            departamentos = (List<Departamento>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            departamentos = new ArrayList<>();
        }
    }

    private void guardarDepartamentos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_DEPARTAMENTOS))) {
            oos.writeObject(departamentos);
        } catch (IOException e) {
            mostrarAlerta("Error", "Hubo un error al guardar los departamentos.");
        }
    }

    private void cargarTecnicosDesdeArchivo() {
        tecnicosDisponibles.clear();

        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO_USUARIOS))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",", -1);
                if (datos.length >= 9) {
                    String codigoUsuario = datos[0];
                    String nombre = datos[1];
                    String apellido = datos[2];
                    String correo = datos[3];
                    String contraseña = datos[4];
                    String telefono = datos[5];
                    String rol = datos[6];
                    String area = datos[7];
                    String ingreso = datos[8];

                    if ("Técnico".equalsIgnoreCase(rol)) {
                        Tecnico tecnico = new Tecnico(codigoUsuario, nombre, apellido, correo,
                                contraseña, telefono, rol, area, ingreso);
                        tecnicosDisponibles.add(tecnico);
                    }
                }
            }
        } catch (Exception e) {
            mostrarAlerta("Error", "No se pudo cargar técnicos desde usuarios.txt");
            e.printStackTrace();
        }

        cbxTecnico.setItems(FXCollections.observableArrayList(tecnicosDisponibles));
    }

    @FXML
    private void Agregar(ActionEvent event) {
        String nombre = fldDepartamento.getText().trim();
        String descripcion = fldDescripcion.getText().trim();
        Tecnico tecnico = cbxTecnico.getSelectionModel().getSelectedItem();
        LocalDate creacion = dateCreacion.getValue();
        LocalDate cierre = dateCierre.getValue();

        if (nombre.isEmpty() || descripcion.isEmpty() || tecnico == null || creacion == null) {
            mostrarAlerta("Error", "Por favor, complete todos los campos requeridos.");
            return;
        }

        // Validar que no exista el departamento ya
        boolean existe = departamentos.stream().anyMatch(d -> d.getNombre().equalsIgnoreCase(nombre));
        if (existe) {
            mostrarAlerta("Error", "El departamento ya existe.");
            return;
        }

        Departamento nuevo = new Departamento(nombre, descripcion);
        nuevo.setTecnico(tecnico);
        nuevo.setFechaCreacion(creacion);
        nuevo.setFechaCierre(cierre);

        departamentos.add(nuevo);
        guardarDepartamentos();

        mostrarAlerta("Éxito", "Departamento agregado correctamente.");
        limpiarCampos();
    }

    @FXML
    private void Eliminar(ActionEvent event) {
        String nombre = fldDepartamento.getText().trim();

        if (nombre.isEmpty()) {
            mostrarAlerta("Error", "Ingrese el nombre del departamento a eliminar.");
            return;
        }

        boolean eliminado = departamentos.removeIf(d -> d.getNombre().equalsIgnoreCase(nombre));
        if (eliminado) {
            guardarDepartamentos();
            mostrarAlerta("Éxito", "Departamento eliminado correctamente.");
            limpiarCampos();
        } else {
            mostrarAlerta("Error", "No se encontró un departamento con ese nombre.");
        }
    }

    @FXML
    private void eventRegresar(ActionEvent event) {
        try {
            guardarDepartamentos();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Sistema.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) btlRegresar.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void limpiarCampos() {
        fldDepartamento.clear();
        fldDescripcion.clear();
        cbxTecnico.getSelectionModel().clearSelection();
        dateCreacion.setValue(null);
        dateCierre.setValue(null);
    }
}