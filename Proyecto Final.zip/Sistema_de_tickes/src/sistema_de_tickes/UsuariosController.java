package sistema_de_tickes;

import Modelos.Persona;
import Modelos.Usuario;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author denil
 */

public class UsuariosController implements Initializable {

    private List<Persona> usuarios = new ArrayList<>();
    private Usuario usuarioRegistrado;
    private final String ARCHIVO_USUARIOS = "usuarios.txt";

    @FXML private Pane txtArea;
    @FXML private TextField fldNombre, fldApellido, fldCorreo, fldContraseña, fldTelefono, fldArea;
    @FXML private DatePicker fldIngreso;
    @FXML private ComboBox<String> cbxRol;
    @FXML private ComboBox<String> cbxDepartamento;
    @FXML private Label txtDepartamento;
    @FXML private Button btnRegistrar, btnLimpiar, btnRegresar;
    @FXML private Label txtUsuario;
    @FXML private Label txtNombre;
    @FXML private Label txtContraseña;
    @FXML private Label txtRol;
    @FXML private TextField fldCodigoUsuario;
    @FXML private Label txtTelefono;
    @FXML private Label txtRol11;
    @FXML private Label txtIngreso;
    @FXML private Label txtApellido;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cbxRol.setItems(FXCollections.observableArrayList("Administrador", "Técnico", "Usuario"));
        cbxDepartamento.setItems(FXCollections.observableArrayList("Soporte", "Desarrollo", "Infraestructura"));

        cbxDepartamento.setVisible(false);
        txtDepartamento.setVisible(false);

        cbxRol.setOnAction(e -> {
            String rolSeleccionado = cbxRol.getValue();
            boolean esTecnico = "Técnico".equals(rolSeleccionado);
            cbxDepartamento.setVisible(esTecnico);
            txtDepartamento.setVisible(esTecnico);
        });

        // Cargar usuarios desde archivo al iniciar la interfaz
        cargarUsuariosDesdeArchivo();
    }

    @FXML
    private void eventRegresar(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Sistema.fxml"));
            Scene scene = new Scene(loader.load());
            Stage stage = (Stage) btnRegresar.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void evenRegistrar(ActionEvent event) {
        String usuario = fldCodigoUsuario.getText().trim();
        String nombre = fldNombre.getText().trim();
        String apellido = fldApellido.getText().trim();
        String correo = fldCorreo.getText().trim();
        String contraseña = fldContraseña.getText().trim();
        String telefono = fldTelefono.getText().trim();
        String rol = cbxRol.getValue();
        String area = fldArea.getText().trim();
        String ingreso = fldIngreso.getValue() != null ? fldIngreso.getValue().toString() : "";
        String departamento = cbxDepartamento.getValue() != null ? cbxDepartamento.getValue() : "";

        if (!validarCampos(usuario, nombre, apellido, correo, contraseña, telefono, rol, ingreso)) {
            mostrarAlerta("Campos inválidos", "Completa correctamente todos los campos requeridos.", Alert.AlertType.WARNING);
            return;
        }

        if (!validarCorreo(correo)) {
            mostrarAlerta("Correo inválido", "El correo electrónico no tiene un formato válido.", Alert.AlertType.WARNING);
            return;
        }

        if (!validarContraseña(contraseña)) {
            mostrarAlerta("Contraseña insegura", "Debe tener al menos 8 caracteres, una mayúscula, un número y un carácter especial.", Alert.AlertType.WARNING);
            return;
        }

        if (telefono.length() < 7) {
            mostrarAlerta("Teléfono inválido", "El número de teléfono debe tener al menos 7 dígitos.", Alert.AlertType.WARNING);
            return;
        }

        if ("Técnico".equals(rol) && departamento.isEmpty()) {
            mostrarAlerta("Departamento requerido", "Debes seleccionar un departamento si el rol es Técnico.", Alert.AlertType.WARNING);
            return;
        }

        if (existeUsuario(correo, usuario)) {
            return;
        }

        Persona nuevoUsuario = new Persona(usuario, nombre, apellido, correo, contraseña, telefono, rol, area, ingreso, departamento);
        usuarios.add(nuevoUsuario);

      
        guardarUsuariosEnArchivo();

        registrarAccion(usuario, "Registro", "Rol: " + rol + (rol.equals("Técnico") ? ", Departamento: " + departamento : ""));
        mostrarAlerta("Éxito", "Usuario registrado correctamente.", Alert.AlertType.INFORMATION);
        limpiarCampos();
    }

    @FXML
    private void eventLimpiar(ActionEvent event) {
        limpiarCampos();
    }

    private void limpiarCampos() {
        fldCodigoUsuario.clear();
        fldNombre.clear();
        fldApellido.clear();
        fldCorreo.clear();
        fldContraseña.clear();
        fldTelefono.clear();
        fldArea.clear();
        fldIngreso.setValue(null);
        cbxRol.setValue(null);
        cbxDepartamento.setValue(null);
        cbxDepartamento.setVisible(false);
        txtDepartamento.setVisible(false);
    }

    private void mostrarAlerta(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    public static void registrarAccion(String usuario, String accion, String detalles) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("historial_usuarios.txt", true))) {
            String fechaHora = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            String linea = String.format("[%s] Usuario: %s - Acción: %s - Detalles: %s", fechaHora, usuario, accion, detalles);
            writer.println(linea);
        } catch (Exception e) {
            System.err.println("Error al registrar historial: " + e.getMessage());
        }
    }

    private boolean validarCampos(String usuario, String nombre, String apellido, String correo, String contraseña, String telefono, String rol, String ingreso) {
        return !(usuario.length() < 5 || usuario.length() > 30 ||
            nombre.length() < 3 || nombre.length() > 100 ||
            apellido.isEmpty() || correo.isEmpty() || contraseña.isEmpty() ||
            telefono.isEmpty() || rol.isEmpty() || ingreso.isEmpty());
    }

    private boolean validarCorreo(String correo) {
        return correo.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
    }

    private boolean validarContraseña(String contraseña) {
        return contraseña.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$");
    }

    private boolean existeUsuario(String correo, String usuario) {
        for (Persona p : usuarios) {
            if (p.getCorreo().equalsIgnoreCase(correo)) {
                mostrarAlerta("Correo duplicado", "Este correo ya está registrado.", Alert.AlertType.ERROR);
                return true;
            }
            if (p.getCodigoUsuario().equalsIgnoreCase(usuario)) {
                mostrarAlerta("Usuario duplicado", "Este nombre de usuario ya existe.", Alert.AlertType.ERROR);
                return true;
            }
        }
        return false;
    }

    private void guardarUsuariosEnArchivo() {
    try (PrintWriter writer = new PrintWriter(new FileWriter(ARCHIVO_USUARIOS))) {
        for (Persona p : usuarios) {
           
            String ingresoStr = p.getIngreso() != null ? p.getIngreso().toString() : "";

            
            String departamento = "";
            if (p instanceof Usuario) {
                departamento = ((Usuario) p).getDepartamento();
            }

            String linea = String.join(",",
                p.getCodigoUsuario(),
                p.getNombre(),
                p.getApellido(),
                p.getCorreo(),
                p.getContraseña(),
                p.getTelefono(),
                p.getRol(),
                p.getArea(),
                ingresoStr,
                departamento
            );

            writer.println(linea);
        }
    } catch (Exception e) {
        System.err.println("Error guardando usuarios: " + e.getMessage());
    }
}
    private void cargarUsuariosDesdeArchivo() {
    usuarios.clear();
    try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO_USUARIOS))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            String[] datos = linea.split(",", -1);
            if (datos.length >= 9) {
                String codigoUsuario = datos[0];
                String nombre = datos[1];
                String apellido = datos[2];
                String correo = datos[3];
                String contraseña = datos[4];
                String telefono = datos[5];
                String rol = datos[6];
                String area = datos[7];
                String ingreso = datos[8];
                String departamento = datos.length > 9 ? datos[9] : "";

                if ("Técnico".equalsIgnoreCase(rol)) {
                   
                    Usuario u = new Usuario(codigoUsuario, nombre, apellido, correo, contraseña, telefono, rol, area, ingreso, departamento);
                    usuarios.add(u);
                } else {
                   
                    Persona p = new Persona(codigoUsuario, nombre, apellido, correo, contraseña, telefono, rol, area, ingreso);
                    usuarios.add(p);
                }
            }
        }
    } catch (Exception e) {
        System.err.println("No se pudo cargar usuarios: " + e.getMessage());
    }
}

    public Usuario getUsuario() {
        return usuarioRegistrado;
    }
}