package sistema_de_tickes;

import Modelos.Tickets;
import Modelos.Estado;
import sistema_de_tickes.Persistencia;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
/**
 * 
 *
 * @author denil
 */

public class Cambiar_Estado_ticketController implements Initializable  {

    @FXML private Label lblTicketId;
    @FXML private ComboBox<Estado> cbxNuevoEstado;
    @FXML private TextArea txtComentario;
    @FXML private Button btnConfirmar;
    @FXML private Button btnCancelar;

    private Tickets ticketSeleccionado;
    private String usuarioActual;
    private String rolActual;
    private List<Tickets> listaTickets;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cbxNuevoEstado.getItems().setAll(Estado.values());
    }

    public void inicializarDatos(Tickets ticket, String usuario, String rol, List<Tickets> listaCompleta) {
        this.ticketSeleccionado = ticket;
        this.usuarioActual = usuario;
        this.rolActual = rol;
        this.listaTickets = listaCompleta;

        lblTicketId.setText("Ticket #" + ticket.getId());
        cbxNuevoEstado.getItems().removeIf(e -> !esTransicionValida(ticket.getEstado(), e));
    }

    private boolean esTransicionValida(Estado actual, Estado nuevo) {
       
        switch (actual) {
            case PENDIENTE:
                return nuevo == Estado.EN_PROCESO || nuevo == Estado.CERRADO;
            case EN_PROCESO:
                return nuevo == Estado.PENDIENTE || nuevo == Estado.CERRADO;
            case CERRADO:
                return nuevo == Estado.EN_PROCESO || nuevo == Estado.CERRADO;
            case RESUELTO:
                return false;
            default:
                return false;
        }
    }

    @FXML
    private void confirmarCambioEstado() {
        Estado nuevoEstado = cbxNuevoEstado.getValue();
        if (nuevoEstado == null) {
            mostrarAlerta("Debes seleccionar un nuevo estado.");
            return;
        }

        if (!esTransicionValida(ticketSeleccionado.getEstado(), nuevoEstado)) {
            mostrarAlerta("Transición no permitida desde " + ticketSeleccionado.getEstado() + " a " + nuevoEstado);
            return;
        }

        String comentario = txtComentario.getText().trim();
        ticketSeleccionado.cambiarEstado(nuevoEstado, usuarioActual);

        if (!comentario.isEmpty()) {
            ticketSeleccionado.agregarNota(usuarioActual, "Comentario de cambio de estado: " + comentario);
        }

        Persistencia.guardarListaTickets(listaTickets);
        mostrarAlerta("El estado ha sido actualizado exitosamente.");
        enviarNotificacion(ticketSeleccionado);
        cerrarVentana();
    }

    @FXML
    private void cancelar() {
        cerrarVentana();
    }

    private void cerrarVentana() {
        Stage stage = (Stage) btnCancelar.getScene().getWindow();
        stage.close();
    }

    private void mostrarAlerta(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Información");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void enviarNotificacion(Tickets ticket) {
     
        System.out.println("Notificación enviada a " + ticket.getCreadoPor() +
                ": El estado del ticket #" + ticket.getId() +
                " ha cambiado a " + ticket.getEstado());
    }
}