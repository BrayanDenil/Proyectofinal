package Modelos;

/**
 * Autor: denil
 */
public class Transicion {
    private Estado estadoOrigen; 
    private Estado estadoDestino ;  
    private String regla;  

 
    public Transicion(Estado estadoOrigen, Estado estadoDestino, String regla) {
          this.estadoOrigen = estadoOrigen;
        this.estadoDestino = estadoDestino;
        this.regla = null;
    }

 

    public Estado getEstadoOrigen() {
        return estadoOrigen;
    }

    public void setEstadoOrigen(Estado estadoOrigen) {
        this.estadoOrigen = estadoOrigen;
    }

    public Estado getEstadoDestino() {
        return estadoDestino;
    }

    public void setEstadoDestino(Estado estadoDestino) {
        this.estadoDestino = estadoDestino;
    }

    public String getRegla() {
        return regla;
    }

    public void setRegla(String regla) {
        this.regla = regla;
    }

    @Override
    public String toString() {
        return "Transicion{" + "estadoOrigen=" + estadoOrigen + ", estadoDestino=" + estadoDestino + ", regla=" + regla + '}';
    }


}


 

