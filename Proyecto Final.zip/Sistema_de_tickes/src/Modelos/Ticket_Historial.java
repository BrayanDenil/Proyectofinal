package Modelos;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * 
 * Autor: denil
 */
public class Ticket_Historial implements Serializable {
    private final LocalDateTime timestamp;
    private final String usuario;
    private final String accion;
    private final String detalles;

    public Ticket_Historial(String usuario, String accion, String detalles) {
        this.timestamp = LocalDateTime.now();
        this.usuario = usuario != null ? usuario : "Desconocido";
        this.accion = accion != null ? accion : "Sin acción";
        this.detalles = detalles != null ? detalles : "Sin detalles";
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getAccion() {
        return accion;
    }

    public String getDetalles() {
        return detalles;
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return "[" + timestamp.format(formatter) + "] " + usuario + " - " + accion + " - " + detalles;
    }
}
