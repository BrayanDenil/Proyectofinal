package Modelos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Modelos.ConexionBD;

public class UsuarioDAO {
    public void listarUsuarios() {
        Connection conn = ConexionBD.conectar();
        if (conn != null) {
            try {
                String query = "SELECT * FROM usuarios";
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    System.out.println("Usuario: " + rs.getString("nombre"));
                }

                rs.close();
                stmt.close();
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}