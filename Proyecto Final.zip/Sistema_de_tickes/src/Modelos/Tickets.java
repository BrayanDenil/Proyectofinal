package Modelos;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Tickets implements Serializable {
    private static int contadorId = 1;

    private int id;
    private String titulo;
    private String descripcion;
    private Departamento departamentoAsignado;
    private String prioridad;
    private List<String> adjuntos;
    private Estado estado;
    private String creadoPor;
    private LocalDate fechaCreacion;
    private String tecnicoAsignado;
    private List<String> historial;
    private List<String> notas;

    public Tickets(String titulo, String descripcion, Departamento departamentoAsignado, String prioridad, String creadoPor) {
        this.id = contadorId++;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.departamentoAsignado = departamentoAsignado;
        this.prioridad = prioridad;
        this.adjuntos = new ArrayList<>();
        this.estado = Estado.PENDIENTE;
        this.creadoPor = creadoPor;
        this.fechaCreacion = LocalDate.now();
        this.tecnicoAsignado = null;
        this.historial = new ArrayList<>();
        this.notas = new ArrayList<>();

        this.historial.add("Ticket creado por " + creadoPor + " el " + fechaCreacion);
    }

    // Métodos funcionales

    public void agregarAdjunto(String path) {
        adjuntos.add(path);
    }

    public void agregarNota(String usuario, String nota) {
        notas.add(usuario + ": " + nota);
        historial.add("Nota agregada por " + usuario);
    }

    public void cambiarEstado(Estado nuevoEstado, String comentario) {
        this.estado = nuevoEstado;
        if (comentario != null && !comentario.isEmpty()) {
            agregarNota("Sistema", comentario);
        }
    }

    public boolean tomarTicket(String tecnico) {
        if (estado == Estado.PENDIENTE) {
            this.estado = Estado.EN_PROCESO;
            this.tecnicoAsignado = tecnico;
            historial.add("Ticket tomado por " + tecnico);
            return true;
        }
        return false;
    }

    public void agregarHistorial(String evento) {
        historial.add(evento);
    }

    // Getters y Setters

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Departamento getDepartamentoAsignado() {
        return departamentoAsignado;
    }

    public void setDepartamentoAsignado(Departamento departamentoAsignado) {
        this.departamentoAsignado = departamentoAsignado;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public List<String> getAdjuntos() {
        return adjuntos;
    }

    public void setAdjuntos(List<String> adjuntos) {
        this.adjuntos = adjuntos;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public String getCreadoPor() {
        return creadoPor;
    }

    public void setCreadoPor(String creadoPor) {
        this.creadoPor = creadoPor;
    }

    public LocalDate getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDate fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getTecnicoAsignado() {
        return tecnicoAsignado;
    }

    public void setTecnicoAsignado(String tecnicoAsignado) {
        this.tecnicoAsignado = tecnicoAsignado;
    }

    public List<String> getHistorial() {
        return historial;
    }

    public void setHistorial(List<String> historial) {
        this.historial = historial;
    }

    public List<String> getNotas() {
        return notas;
    }

    public void setNotas(List<String> notas) {
        this.notas = notas;
    }

    @Override
    public String toString() {
        return "Tickets{" +
                "id=" + id +
                ", titulo='" + titulo + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", departamentoAsignado=" + departamentoAsignado +
                ", prioridad='" + prioridad + '\'' +
                ", adjuntos=" + adjuntos +
                ", estado=" + estado +
                ", creadoPor='" + creadoPor + '\'' +
                ", fechaCreacion=" + fechaCreacion +
                ", tecnicoAsignado='" + tecnicoAsignado + '\'' +
                ", historial=" + historial +
                ", notas=" + notas +
                '}';
    }

    public Object getDepartamento() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}