package Modelos;

import java.util.ArrayList;
import java.util.List;

/**
 * Gestión de Tickets
 * @author denil
 */
public class Gestion_De_Tickets {

    private final List<Tickets> tickets;

    public Gestion_De_Tickets(List<Tickets> ticketsIniciales) {
        this.tickets = (ticketsIniciales != null) ? ticketsIniciales : new ArrayList<>();
    }

    public void crearTicket(String descripcion, Usuario usuarioSolicitante) {
        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException("La descripción no puede estar vacía.");
        }
        if (usuarioSolicitante == null) {
            throw new IllegalArgumentException("El usuario solicitante no puede ser nulo.");
        }

        int nuevoId = tickets.size() + 1;
        String titulo = "Ticket #" + nuevoId;
        Departamento departamentoAsignado = new Departamento("Soporte Técnico", "Departamento de soporte técnico");
        String prioridad = "Media";

        Tickets nuevoTicket = new Tickets(titulo, descripcion, departamentoAsignado, prioridad, usuarioSolicitante.getNombre());
        tickets.add(nuevoTicket);
    }

    public List<Tickets> obtenerTodosLosTickets() {
        return new ArrayList<>(tickets);
    }

    public List<Tickets> obtenerTicketsPendientes() {
        List<Tickets> pendientes = new ArrayList<>();
        for (Tickets ticket : tickets) {
            if (ticket.getEstado() == Estado.PENDIENTE) {
                pendientes.add(ticket);
            }
        }
        return pendientes;
    }

    public void cambiarEstadoTicket(int ticketId, Estado nuevoEstado, String comentario) {
        if (nuevoEstado == null) {
            throw new IllegalArgumentException("El nuevo estado no puede ser nulo.");
        }

        Tickets ticket = buscarTicketPorId(ticketId);
        if (ticket != null) {
            ticket.cambiarEstado(nuevoEstado, comentario);
        } else {
            throw new IllegalArgumentException("Ticket no encontrado con ID: " + ticketId);
        }
    }

    public void agregarNota(int ticketId, String usuario, String nota) {
        if (nota == null || nota.trim().isEmpty()) {
            throw new IllegalArgumentException("La nota no puede ser nula o vacía.");
        }
        if (usuario == null || usuario.trim().isEmpty()) {
            throw new IllegalArgumentException("El usuario no puede ser nulo o vacío.");
        }

        Tickets ticket = buscarTicketPorId(ticketId);
        if (ticket != null) {
            ticket.agregarNota(usuario, nota);
        } else {
            throw new IllegalArgumentException("Ticket no encontrado con ID: " + ticketId);
        }
    }

    private Tickets buscarTicketPorId(int id) {
        for (Tickets ticket : tickets) {
            if (ticket.getId() == id) {
                return ticket;
            }
        }
        return null;
    }
}