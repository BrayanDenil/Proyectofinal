package Modelos;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.Queue;

/**

 *
 * @author denil
 */

public class ColaAtencion implements Serializable {

    private static final long serialVersionUID = 1L;

    private Queue<Tickets> tickets;

    public ColaAtencion() {
        this.tickets = new LinkedList<>();
    }

    
     
    public boolean estaVacia() {
    return tickets.isEmpty();
}

    public void agregarTicket(Tickets ticket) {
        tickets.add(ticket); 
    }

  
     
    public Tickets tomarTicket() {
        return tickets.poll();
    }

    public Queue<Tickets> getTickets() {
        return tickets;
    }

    public void setTickets(Queue<Tickets> tickets) {
        this.tickets = tickets;
    }

    public ColaAtencion(Queue<Tickets> tickets) {
        this.tickets = tickets;
    }
    
   
    
}