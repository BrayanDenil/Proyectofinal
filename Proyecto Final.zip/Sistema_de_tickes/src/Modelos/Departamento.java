package Modelos;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * 
 * Autor: denil
 */
public class Departamento implements Serializable {

    private static final long serialVersionUID = 1L;

    private String nombre;
    private String descripcion;
    private List<Tecnico> tecnicoAsignados;
    private Queue<Tickets> colaAtencion;
    private String soporteTecnico;

    private LocalDate fechaCreacion;
    private LocalDate fechaCierre;

   
    public Departamento(String nombre, String descripcion, String soporteTecnico) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.soporteTecnico = soporteTecnico;
        this.tecnicoAsignados = new ArrayList<>();
        this.colaAtencion = new LinkedList<>();
        this.fechaCreacion = LocalDate.now();
    }

    // Constructor comúnmente usado
    public Departamento(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.tecnicoAsignados = new ArrayList<>();
        this.colaAtencion = new LinkedList<>();
        this.fechaCreacion = LocalDate.now();
    }

    public Departamento(String soporteTecnico) {
        this.soporteTecnico = soporteTecnico;
        this.tecnicoAsignados = new ArrayList<>();
        this.colaAtencion = new LinkedList<>();
        this.fechaCreacion = LocalDate.now();
    }

  
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public List<Tecnico> getTecnicoAsignados() {
        return tecnicoAsignados;
    }

    public void setTecnicoAsignados(List<Tecnico> tecnicoAsignados) {
        this.tecnicoAsignados = tecnicoAsignados;
    }

    public Queue<Tickets> getColaAtencion() {
        return colaAtencion;
    }

    public void setColaAtencion(Queue<Tickets> colaAtencion) {
        this.colaAtencion = colaAtencion;
    }

    public String getSoporteTecnico() {
        return soporteTecnico;
    }

    public void setSoporteTecnico(String soporteTecnico) {
        this.soporteTecnico = soporteTecnico;
    }

    public LocalDate getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDate fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public LocalDate getFechaCierre() {
        return fechaCierre;
    }

    public void setFechaCierre(LocalDate fechaCierre) {
        this.fechaCierre = fechaCierre;
    }

   
    public void agregarTicket(Tickets nuevoTicket) {
        colaAtencion.add(nuevoTicket);
    }

    @Override
    public String toString() {
        return nombre;
    }

    
    public boolean equalsIgnoreCase(String nombre) {
        return this.nombre != null && this.nombre.equalsIgnoreCase(nombre);
    }

    public void setTecnico(Tecnico tecnico) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}