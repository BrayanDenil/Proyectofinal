package Modelos;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 
 * 
 * @author denil
 */

public class Nota {

    private String contenido;
    private File archivoAdjunto;  
    private final Date fechaCreacion;

  
    public Nota(String contenido, File archivoAdjunto) {
        if (contenido == null || contenido.trim().isEmpty()) {
            throw new IllegalArgumentException("El contenido de la nota no puede estar vacío.");
        }
        this.contenido = contenido;
        this.archivoAdjunto = archivoAdjunto;
        this.fechaCreacion = new Date();
    }

   
    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        if (contenido == null || contenido.trim().isEmpty()) {
            throw new IllegalArgumentException("El contenido no puede estar vacío.");
        }
        this.contenido = contenido;
    }

    public File getArchivoAdjunto() {
        return archivoAdjunto;
    }

    public void setArchivoAdjunto(File archivoAdjunto) {
        this.archivoAdjunto = archivoAdjunto;
    }

    public Date getFechaCreacion() {
        return new Date(fechaCreacion.getTime()); 
    }

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return "Nota: " + contenido + " (Fecha: " + sdf.format(fechaCreacion) + ")";
    }
}
