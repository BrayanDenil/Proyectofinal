package Modelos;
/**
 * 
 * 
 * @author denil
 */
public enum Estado {
    PENDIENTE {
        @Override
        public String toString() {
            return "Pendiente";
        }
        @Override
        public boolean esFinal() {
            return false;
        }
    },
    ABIERTO {
        @Override
        public String toString() {
            return "Abierto";
        }
        @Override
        public boolean esFinal() {
            return false;
        }
    },
    EN_PROCESO {
        @Override
        public String toString() {
            return "En Proceso";
        }
        @Override
        public boolean esFinal() {
            return false;
        }
    },
    CERRADO {
        @Override
        public String toString() {
            return "Cerrado";
        }
        @Override
        public boolean esFinal() {
            return true;
        }
    },
    RESUELTO {
        @Override
        public String toString() {
            return "Resuelto";
        }
        @Override
        public boolean esFinal() {
            return true;
        }
    };

    public abstract boolean esFinal();
}