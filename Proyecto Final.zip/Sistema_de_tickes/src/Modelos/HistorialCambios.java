
package Modelos;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

/**
 * 
 * 
 * @author denil
 */
public class HistorialCambios {
    private String usuario;
    private LocalDateTime fechaHora;
    private String accion;
    private String detalles;

    public HistorialCambios(String usuario, LocalDateTime fechaHora, String accion, String detalles) {
        this.usuario = usuario;
        this.fechaHora = fechaHora;
        this.accion = accion;
        this.detalles = detalles;
    }

    public String getUsuario() { return usuario; }
    public LocalDateTime getFechaHora() { return fechaHora; }
    public String getAccion() { return accion; }
    public String getDetalles() { return detalles; }

    

    public String getRegistroCompleto() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return "[" + fechaHora.format(formatter) + "] Usuario: " + usuario + " - " + accion + "\nDetalles: " + detalles;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setFechaHora(LocalDateTime fechaHora) {
        this.fechaHora = fechaHora;
    }

    public void setAccion(String accion) {
        this.accion = accion;
    }

    public void setDetalles(String detalles) {
        this.detalles = detalles;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 23 * hash + Objects.hashCode(this.usuario);
        hash = 23 * hash + Objects.hashCode(this.fechaHora);
        hash = 23 * hash + Objects.hashCode(this.accion);
        hash = 23 * hash + Objects.hashCode(this.detalles);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final HistorialCambios other = (HistorialCambios) obj;
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        if (!Objects.equals(this.accion, other.accion)) {
            return false;
        }
        if (!Objects.equals(this.detalles, other.detalles)) {
            return false;
        }
        if (!Objects.equals(this.fechaHora, other.fechaHora)) {
            return false;
        }
        return true;
    }
    
    
}


